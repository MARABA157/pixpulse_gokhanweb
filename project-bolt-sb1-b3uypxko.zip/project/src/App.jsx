import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Home from './pages/Home'
import SignIn from './pages/SignIn'
import SignUp from './pages/SignUp'
import Profile from './pages/Profile'
import ImageGenerator from './pages/ImageGenerator'
import VideoGenerator from './pages/VideoGenerator'
import AIChatPage from './pages/AIChatPage'
import ForgotPassword from './pages/ForgotPassword'
import ResetPassword from './pages/ResetPassword'
import Premium from './pages/Premium'

export default function App() {
  return (
    <div className="min-h-screen bg-black">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/generate-image" element={<ImageGenerator />} />
        <Route path="/generate-video" element={<VideoGenerator />} />
        <Route path="/ai-chat" element={<AIChatPage />} />
        <Route path="/premium" element={<Premium />} />
      </Routes>
    </div>
  )
}