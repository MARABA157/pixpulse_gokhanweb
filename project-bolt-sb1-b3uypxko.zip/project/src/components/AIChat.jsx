import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { chatWithAI } from '../lib/openai';
import { useAuth } from '../contexts/AuthContext';

export default function AIChat() {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const { user, isPremium, hasTrials, trialCount, useGuestTrial } = useAuth();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!message.trim()) return;

    // Kullanıcı giriş yapmamışsa ve deneme hakkı kalmamışsa
    if (!user && !hasTrials) {
      setMessages(prev => [...prev, {
        text: 'Deneme hakkınız doldu. Devam etmek için lütfen giriş yapın.',
        sender: 'system'
      }]);
      return;
    }

    // Premium olmayan kullanıcılar için kontrol
    if (user && !isPremium) {
      setMessages(prev => [...prev, {
        text: 'Bu özelliği kullanmak için premium üyelik gerekiyor.',
        sender: 'system'
      }]);
      return;
    }

    // Misafir kullanıcı için deneme hakkı kullan
    if (!user) {
      if (!useGuestTrial()) {
        setMessages(prev => [...prev, {
          text: 'Deneme hakkınız doldu. Devam etmek için lütfen giriş yapın.',
          sender: 'system'
        }]);
        return;
      }
    }
    
    const userMessage = message.trim();
    setMessage('');
    setMessages(prev => [...prev, { text: userMessage, sender: 'user' }]);
    setLoading(true);
    
    try {
      const response = await chatWithAI(userMessage);
      setMessages(prev => [...prev, {
        text: response,
        sender: 'ai'
      }]);
    } catch (error) {
      console.error('Sohbet hatası:', error);
      setMessages(prev => [...prev, {
        text: 'Üzgünüm, şu anda yanıt veremiyorum. Lütfen daha sonra tekrar deneyin.',
        sender: 'system'
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-black/100 backdrop-blur-md rounded-xl p-6 border border-white/10 shadow-xl">
      <h3 className="text-xl font-semibold text-white mb-4">Yapay Zeka Sohbet</h3>
      
      {!user && (
        <div className="mb-4 p-4 rounded-xl bg-purple-900/50 backdrop-blur">
          <p className="text-white mb-2">
            {hasTrials 
              ? `Kalan deneme hakkı: ${trialCount}`
              : 'Deneme hakkınız doldu. Devam etmek için giriş yapın.'}
          </p>
          {!hasTrials && (
            <Link
              to="/signin"
              className="inline-block bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-500 transition-colors"
            >
              Giriş Yap
            </Link>
          )}
        </div>
      )}

      {user && !isPremium && (
        <div className="mb-4 p-4 rounded-xl bg-purple-900/50 backdrop-blur">
          <p className="text-white mb-2">Premium üyelik ile sınırsız sohbet edin!</p>
          <Link
            to="/premium"
            className="inline-block bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-500 transition-colors"
          >
            Premium'a Geç
          </Link>
        </div>
      )}

      <div className="h-[500px] overflow-y-auto mb-4 space-y-4 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent pr-4">
        {messages.map((msg, index) => (
          <div
            key={index}
            className={`p-4 rounded-xl ${
              msg.sender === 'user'
                ? 'bg-purple-900/50 backdrop-blur ml-auto max-w-[80%]'
                : msg.sender === 'ai'
                ? 'bg-gray-800/50 backdrop-blur mr-auto max-w-[80%]'
                : 'bg-red-900/50 backdrop-blur mx-auto max-w-[90%] text-center'
            }`}
          >
            <p className="text-white text-sm whitespace-pre-wrap leading-relaxed">{msg.text}</p>
          </div>
        ))}
        {loading && (
          <div className="flex justify-center items-center space-x-2 p-4">
            <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
            <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
            <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Yapay zeka ile sohbet edin..."
          className="flex-1 bg-black/50 border border-gray-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
          disabled={(!user && !hasTrials) || (user && !isPremium)}
        />
        <button
          type="submit"
          disabled={loading || !message.trim() || (!user && !hasTrials) || (user && !isPremium)}
          className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-xl font-medium hover:from-purple-500 hover:to-pink-500 transition-all transform hover:scale-[1.02] disabled:opacity-50 disabled:hover:scale-100 disabled:cursor-not-allowed whitespace-nowrap"
        >
          {loading ? 'Yanıtlanıyor...' : 'Gönder'}
        </button>
      </form>
    </div>
  );
}