import { Link } from 'react-router-dom';

export default function CitySlideshow() {
  return (
    <div className="relative h-96 mb-8 flex items-center justify-center">
      <div className="max-w-4xl mx-auto px-8 w-full">
        <div className="space-y-6 text-center">
          <h1 className="text-5xl font-bold">
            <span className="bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text">
              Yapay Zeka ile Sınırları Aşın
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Hayal edin, yapay zeka gerçeğe dönüştürsün. Saniyeler içinde muhteşem içerikler.
          </p>
          <div className="flex gap-4 justify-center">
            <Link 
              to="/generate-image" 
              className="px-8 py-3 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold hover:from-purple-500 hover:to-pink-500 transform hover:scale-105 transition-all shadow-lg hover:shadow-purple-500/25 cursor-pointer"
            >
              Hemen Başla
            </Link>
            <Link 
              to="/ai-chat" 
              className="px-8 py-3 rounded-full bg-white/10 backdrop-blur text-white font-semibold hover:bg-white/20 transform hover:scale-105 transition-all cursor-pointer"
            >
              Daha Fazla Bilgi
            </Link>
          </div>
          <div className="mt-12">
            <div className="text-xl text-gray-300 italic">
              "Hayal gücünüzün sınırlarını zorlayın, yapay zeka teknolojimiz ile imkansızı mümkün kılın."
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}