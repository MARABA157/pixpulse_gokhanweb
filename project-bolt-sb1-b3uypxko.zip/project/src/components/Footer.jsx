import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-black/50 backdrop-blur-sm border-t border-gray-800 py-12 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="text-2xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 text-transparent bg-clip-text">PixPulse</h3>
            <p className="text-gray-400 text-sm">
              Yapay zeka ile harika görseller ve videolar oluşturun ve paylaşın. Sınırsız yaratıcılık, sınırsız olasılıklar.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Hızlı Bağlantılar</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-400 hover:text-white text-sm transition-colors">Anasayfa</Link></li>
              <li><Link to="/generate-image" className="text-gray-400 hover:text-white text-sm transition-colors">Görsel Üret</Link></li>
              <li><Link to="/generate-video" className="text-gray-400 hover:text-white text-sm transition-colors">Video Üret</Link></li>
              <li><Link to="/ai-chat" className="text-gray-400 hover:text-white text-sm transition-colors">Yapay Zeka ile Sohbet</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Kaynaklar</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Blog</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Dokümantasyon</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">API</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Örnekler</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">İletişim</h3>
            <ul className="space-y-2">
              <li className="text-gray-400 text-sm">E-posta: info@pixpulse.com</li>
              <li className="text-gray-400 text-sm">Telefon: +90 (212) 123 45 67</li>
              <li className="text-gray-400 text-sm">Adres: İstanbul, Türkiye</li>
            </ul>
            <div className="flex space-x-4 mt-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <i className="fab fa-facebook"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <i className="fab fa-instagram"></i>
              </a>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © {new Date().getFullYear()} PixPulse. Tüm hakları saklıdır.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Gizlilik Politikası</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Kullanım Şartları</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">KVKK</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}