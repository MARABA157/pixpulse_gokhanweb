import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { motion } from 'framer-motion';

export default function Navbar() {
  const { user, signOut, isPremium } = useAuth();

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Çıkış hatası:', error);
    }
  };

  return (
    <nav className="border-b border-gray-800 bg-black/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <Link to="/" className="text-4xl font-bold bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 text-transparent bg-clip-text hover:from-purple-400 hover:to-pink-400 transition-all">
            PixPulse
          </Link>
          <div className="flex items-center space-x-4">
            <Link to="/generate-image" className="px-6 py-2.5 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:from-purple-500 hover:to-blue-500 transition-all">
              Görsel Üret
            </Link>
            <Link to="/generate-video" className="px-6 py-2.5 rounded-full bg-gradient-to-r from-pink-600 to-orange-600 text-white hover:from-pink-500 hover:to-orange-500 transition-all">
              Video Üret
            </Link>
            <Link to="/ai-chat" className="px-6 py-2.5 rounded-full bg-gradient-to-r from-green-600 to-teal-600 text-white hover:from-green-500 hover:to-teal-500 transition-all">
              Yapay Zeka ile Sohbet
            </Link>
            {user ? (
              <div className="flex items-center space-x-4">
                {!isPremium && (
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Link
                      to="/premium"
                      className="px-6 py-2.5 rounded-full bg-gradient-to-r from-yellow-600 to-amber-600 text-white hover:from-yellow-500 hover:to-amber-500 transition-all"
                    >
                      Premium'a Geç
                    </Link>
                  </motion.div>
                )}
                <Link to="/profile" className="px-6 py-2.5 rounded-full bg-gradient-to-r from-indigo-600 to-blue-600 text-white hover:from-indigo-500 hover:to-blue-500 transition-all">
                  Profilim
                </Link>
                <button
                  onClick={handleSignOut}
                  className="px-6 py-2.5 rounded-full bg-gradient-to-r from-red-600 to-orange-600 text-white hover:from-red-500 hover:to-orange-500 transition-all"
                >
                  Çıkış Yap
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Link
                  to="/signin"
                  className="px-6 py-2.5 rounded-full bg-gradient-to-r from-indigo-600 to-blue-600 text-white hover:from-indigo-500 hover:to-blue-500 transition-all"
                >
                  Giriş Yap
                </Link>
                <Link
                  to="/signup"
                  className="px-6 py-2.5 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-500 hover:to-pink-500 transition-all"
                >
                  Kayıt Ol
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}