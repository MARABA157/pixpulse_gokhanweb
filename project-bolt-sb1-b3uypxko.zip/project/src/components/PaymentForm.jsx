import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { initiatePayment, Plans } from '../lib/payment';
import LoadingButton from './LoadingButton';

export default function PaymentForm({ planId, onSuccess }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { user } = useAuth();

  const plan = Plans[planId.toUpperCase()];

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setError(null);
      setLoading(true);

      const payment = await initiatePayment(user.id, planId);
      
      // Ödeme başarılı
      if (payment) {
        onSuccess(payment);
      }
    } catch (error) {
      console.error('Ödeme hatası:', error);
      setError('Ödeme işlemi başarısız oldu. Lütfen daha sonra tekrar deneyin.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="backdrop-blur-xl bg-white/5 rounded-2xl border border-white/10 p-8">
      <h3 className="text-2xl font-bold text-white mb-6">{plan.name} Plan - ₺{plan.price}/ay</h3>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Kart Numarası
          </label>
          <input
            type="text"
            className="w-full bg-black/50 border border-gray-600 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            placeholder="4242 4242 4242 4242"
            maxLength="19"
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Son Kullanma
            </label>
            <input
              type="text"
              className="w-full bg-black/50 border border-gray-600 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="MM/YY"
              maxLength="5"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              CVC
            </label>
            <input
              type="text"
              className="w-full bg-black/50 border border-gray-600 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="123"
              maxLength="3"
              required
            />
          </div>
        </div>

        {error && (
          <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/50 text-red-200 text-sm">
            {error}
          </div>
        )}

        <LoadingButton
          type="submit"
          loading={loading}
          loadingText="İşleniyor..."
          className="w-full"
        >
          ₺{plan.price} Öde
        </LoadingButton>
      </form>

      <div className="mt-6 text-center">
        <p className="text-sm text-gray-400">
          256-bit SSL ile güvenli ödeme
        </p>
      </div>
    </div>
  );
}