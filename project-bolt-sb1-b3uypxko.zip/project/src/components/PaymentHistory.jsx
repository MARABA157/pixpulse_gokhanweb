import { useState, useEffect } from 'react';
import { getPaymentHistory, generateInvoice } from '../lib/payment';
import { useAuth } from '../contexts/AuthContext';
import LoadingSkeleton from './LoadingSkeleton';

export default function PaymentHistory() {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    fetchPayments();
  }, []);

  const fetchPayments = async () => {
    try {
      const data = await getPaymentHistory(user.id);
      setPayments(data);
    } catch (error) {
      console.error('Ödeme geçmişi yüklenemedi:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadInvoice = async (paymentId) => {
    try {
      const invoice = await generateInvoice(paymentId);
      // Fatura indirme işlemi
      console.log('Fatura:', invoice);
    } catch (error) {
      console.error('Fatura indirilemedi:', error);
    }
  };

  if (loading) return <LoadingSkeleton />;

  return (
    <div className="space-y-6">
      <h3 className="text-xl font-bold text-white">Ödeme Geçmişi</h3>
      
      {payments.length === 0 ? (
        <p className="text-gray-400">Henüz bir ödeme geçmişiniz yok.</p>
      ) : (
        <div className="space-y-4">
          {payments.map((payment) => (
            <div
              key={payment.id}
              className="backdrop-blur-xl bg-white/5 rounded-xl border border-white/10 p-4"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-medium">₺{payment.amount}</p>
                  <p className="text-sm text-gray-400">
                    {new Date(payment.created_at).toLocaleDateString('tr-TR')}
                  </p>
                </div>
                <button
                  onClick={() => handleDownloadInvoice(payment.id)}
                  className="text-purple-400 hover:text-purple-300 transition-colors"
                >
                  Faturayı İndir
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}