import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function PaymentSuccess({ plan }) {
  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="text-center"
    >
      <div className="mb-6">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2 }}
          className="w-16 h-16 bg-green-500 rounded-full mx-auto flex items-center justify-center"
        >
          <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </motion.div>
      </div>

      <h3 className="text-2xl font-bold text-white mb-2">
        Ödeme Başarılı!
      </h3>
      
      <p className="text-gray-400 mb-6">
        {plan.name} planına başarıyla abone oldunuz.
      </p>

      <div className="space-y-4">
        <Link
          to="/profile"
          className="block w-full px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-medium hover:from-purple-500 hover:to-pink-500 transition-all"
        >
          Profile Git
        </Link>
        
        <Link
          to="/"
          className="block w-full px-6 py-3 rounded-xl bg-white/10 text-white font-medium hover:bg-white/20 transition-all"
        >
          Ana Sayfaya Dön
        </Link>
      </div>
    </motion.div>
  );
}