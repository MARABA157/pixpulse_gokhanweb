import { motion } from 'framer-motion';

export default function PremiumBadge() {
  return (
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="inline-flex items-center px-3 py-1 rounded-full bg-gradient-to-r from-yellow-400 to-amber-500 text-black text-sm font-medium"
    >
      <svg className="w-4 h-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M10 2a1 1 0 00-.894.553L7.382 6H4a1 1 0 000 2h2.382l-1.724 3.447A1 1 0 004 12v4a2 2 0 002 2h8a2 2 0 002-2v-4a1 1 0 00-.658-.947L13.618 8H16a1 1 0 100-2h-3.382l-1.724-3.447A1 1 0 0010 2zm0 2.618l1.724 3.447a1 1 0 00.894.553H16v3.382l1.724 3.447A1 1 0 0118 16v-4a2 2 0 00-2-2h-8a2 2 0 00-2 2v4c0 .379.214.725.553.894L8.276 13.618V8.382L10 4.618z" clipRule="evenodd" />
      </svg>
      Premium
    </motion.div>
  );
}