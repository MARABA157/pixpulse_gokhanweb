import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function PremiumFeature({ children }) {
  const { user, isPremium } = useAuth();

  if (isPremium) return children;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="relative group"
    >
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm rounded-xl flex items-center justify-center">
        <div className="text-center p-6">
          <h3 className="text-xl font-bold text-white mb-2">Premium Özellik</h3>
          <p className="text-gray-400 mb-4">Bu özelliği kullanmak için premium üyelik gerekiyor.</p>
          <Link
            to="/premium"
            className="inline-block px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-medium hover:from-purple-500 hover:to-pink-500 transition-all transform hover:scale-105"
          >
            Premium'a Geç
          </Link>
        </div>
      </div>
      <div className="opacity-50 pointer-events-none">
        {children}
      </div>
    </motion.div>
  );
}