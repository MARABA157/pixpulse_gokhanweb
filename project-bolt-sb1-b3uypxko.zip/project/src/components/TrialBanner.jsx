import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function TrialBanner({ trialCount }) {
  return (
    <motion.div
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="bg-gradient-to-r from-purple-900/50 to-pink-900/50 backdrop-blur-md border-b border-white/10"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <span className="text-white">
              {trialCount > 0 ? (
                <>Kalan deneme hakkı: <span className="font-bold">{trialCount}</span></>
              ) : (
                'Deneme hakkınız doldu'
              )}
            </span>
          </div>
          <Link
            to="/premium"
            className="px-4 py-2 rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 text-white text-sm font-medium hover:from-purple-500 hover:to-pink-500 transition-all transform hover:scale-105"
          >
            Premium'a Geç
          </Link>
        </div>
      </div>
    </motion.div>
  );
}