import { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { initializeIP, hasTrialsLeft, getTrialCount, incrementTrialCount } from '../lib/guestTrials';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isPremium, setIsPremium] = useState(false);
  const [hasTrials, setHasTrials] = useState(true);
  const [trialCount, setTrialCount] = useState(0);

  useEffect(() => {
    let mounted = true;
    let unsubscribe = () => {};

    const initialize = async () => {
      try {
        await initializeIP();
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) throw error;
        
        if (mounted) {
          const currentUser = session?.user || null;
          setUser(currentUser);
          
          if (currentUser) {
            const { data: profile } = await supabase
              .from('profiles')
              .select('is_premium')
              .eq('id', currentUser.id)
              .single();
            
            setIsPremium(profile?.is_premium || false);
          }

          const trials = hasTrialsLeft();
          setHasTrials(trials);
          setTrialCount(trials ? 3 - getTrialCount() : 0);
        }

        const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
          if (!mounted) return;

          const newUser = session?.user || null;
          setUser(newUser);
          
          if (newUser) {
            const { data: profile } = await supabase
              .from('profiles')
              .select('is_premium')
              .eq('id', newUser.id)
              .single();
            
            setIsPremium(profile?.is_premium || false);
          } else {
            setIsPremium(false);
          }
        });

        unsubscribe = subscription.unsubscribe;
      } catch (error) {
        console.error('Kimlik doğrulama hatası:', error);
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    initialize();

    return () => {
      mounted = false;
      if (typeof unsubscribe === 'function') {
        unsubscribe();
      }
    };
  }, []);

  const useGuestTrial = () => {
    if (!hasTrials) return false;
    const remainingTrials = incrementTrialCount();
    const newHasTrials = remainingTrials < 3;
    setHasTrials(newHasTrials);
    setTrialCount(newHasTrials ? 3 - remainingTrials : 0);
    return true;
  };

  const value = {
    user,
    loading,
    isPremium,
    hasTrials,
    trialCount,
    useGuestTrial,
    signIn: async (email, password) => {
      try {
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password
        });
        if (error) throw error;
        return data.user;
      } catch (error) {
        console.error('Giriş hatası:', error);
        throw error;
      }
    },
    signUp: async (email, password) => {
      try {
        const { data, error } = await supabase.auth.signUp({
          email,
          password
        });
        if (error) throw error;
        return data.user;
      } catch (error) {
        console.error('Kayıt hatası:', error);
        throw error;
      }
    },
    signOut: async () => {
      try {
        const { error } = await supabase.auth.signOut();
        if (error) throw error;
      } catch (error) {
        console.error('Çıkış hatası:', error);
        throw error;
      }
    }
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};