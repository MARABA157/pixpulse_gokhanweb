import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import AIChat from '../components/AIChat';
import Footer from '../components/Footer';

export default function AIChatPage() {
  const [currentBgIndex, setCurrentBgIndex] = useState(0);

  const backgrounds = [
    'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=100&w=3840&h=2160&fit=crop',
    'https://images.unsplash.com/photo-1507413245164-6160d8298b31?q=100&w=3840&h=2160&fit=crop',
    'https://images.unsplash.com/photo-1532094349884-543bc11b234d?q=100&w=3840&h=2160&fit=crop',
    'https://images.unsplash.com/photo-1516110833967-0b5716ca1387?q=100&w=3840&h=2160&fit=crop'
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBgIndex((prevIndex) => (prevIndex + 1) % backgrounds.length);
    }, 2000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen text-white flex flex-col relative overflow-hidden">
      {/* Siyah overlay */}
      <div className="fixed inset-0 bg-black opacity-100 z-0" />
      
      {backgrounds.map((bg, index) => (
        <div
          key={index}
          className={`fixed inset-0 transition-opacity duration-1000 bg-cover bg-center bg-no-repeat ${
            index === currentBgIndex ? 'opacity-50' : 'opacity-0'
          }`}
          style={{
            backgroundImage: `url(${bg})`,
            zIndex: -1
          }}
        />
      ))}
      
      <div className="relative z-10 flex flex-col min-h-screen">
        <nav className="bg-black/100 backdrop-blur-sm border-b border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16 items-center">
              <Link to="/" className="text-3xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 text-transparent bg-clip-text hover:from-purple-400 hover:to-pink-400 transition-all">
                PixPulse
              </Link>
            </div>
          </div>
        </nav>
        <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text text-center">
              Yapay Zeka ile Sohbet
            </h1>
            <p className="text-gray-300 text-center mb-8">
              Projeleriniz için yaratıcı fikirler ve öneriler alın
            </p>
            <AIChat />
          </div>
        </main>
        <Footer />
      </div>
    </div>
  );
}