import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import FormInput from '../components/FormInput';
import LoadingButton from '../components/LoadingButton';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setError(null);
      setMessage(null);
      setLoading(true);

      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) throw error;

      setMessage('Şifre sıfırlama bağlantısı e-posta adresinize gönderildi.');
    } catch (error) {
      console.error('Şifre sıfırlama hatası:', error);
      setError('Şifre sıfırlama bağlantısı gönderilemedi. Lütfen tekrar deneyin.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden py-12 px-4 sm:px-6 lg:px-8">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-gray-900 to-black">
        <div className="absolute inset-0 bg-black opacity-50"></div>
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1620121692029-d088224ddc74?w=1920')] bg-cover bg-center opacity-10"></div>
      </div>

      <div className="relative max-w-md w-full">
        <div className="text-center mb-8">
          <Link to="/" className="inline-block">
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text">
              PixPulse
            </h1>
          </Link>
          <h2 className="mt-2 text-2xl font-semibold text-white">Şifrenizi mi Unuttunuz?</h2>
          <p className="mt-2 text-gray-400">E-posta adresinizi girin, size şifre sıfırlama bağlantısı gönderelim</p>
        </div>

        <div className="backdrop-blur-xl bg-white/10 p-8 rounded-2xl border border-white/20">
          <form onSubmit={handleSubmit} className="space-y-6">
            <FormInput
              label="E-posta"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="ornek@email.com"
              disabled={loading}
              required
            />

            {error && (
              <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/50 text-red-200 text-sm">
                {error}
              </div>
            )}

            {message && (
              <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/50 text-green-200 text-sm">
                {message}
              </div>
            )}

            <LoadingButton
              type="submit"
              loading={loading}
              loadingText="Gönderiliyor..."
            >
              Şifre Sıfırlama Bağlantısı Gönder
            </LoadingButton>
          </form>

          <div className="mt-8 text-center">
            <p className="text-gray-400">
              Giriş yapmak için{' '}
              <Link to="/signin" className="font-medium text-purple-400 hover:text-purple-300 transition-colors">
                buraya tıklayın
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}