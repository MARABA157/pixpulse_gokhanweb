import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom';
import Footer from '../components/Footer';
import CitySlideshow from '../components/CitySlideshow';
import Navbar from '../components/Navbar';

function Home() {
  const [currentBgIndex, setCurrentBgIndex] = useState(0);

  const [exploreImages] = useState([
    { id: 1, url: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=100&w=1920&auto=format&fit=crop', caption: 'Şehir Manzarası' },
    { id: 2, url: 'https://images.unsplash.com/photo-1547891654-e66ed7ebb968?q=100&w=1920&auto=format&fit=crop', caption: 'Modern Mimari' },
    { id: 3, url: 'https://images.unsplash.com/photo-1549490349-8643362247b5?q=100&w=1920&auto=format&fit=crop', caption: 'Doğa Güzelliği' },
    { id: 4, url: 'https://images.unsplash.com/photo-1561214115-f2f134cc4912?q=100&w=1920&auto=format&fit=crop', caption: 'Teknoloji' },
    { id: 5, url: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?q=100&w=1920&auto=format&fit=crop', caption: 'Okyanus' },
    { id: 6, url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=100&w=1920&auto=format&fit=crop', caption: 'Orman' },
    { id: 7, url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=100&w=1920&auto=format&fit=crop', caption: 'Portre' },
    { id: 8, url: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?q=100&w=1920&auto=format&fit=crop', caption: 'Gece Şehri' },
    { id: 9, url: 'https://images.unsplash.com/photo-1444090542259-0af8fa96557e?q=100&w=1920&auto=format&fit=crop', caption: 'Gökyüzü' },
    { id: 10, url: 'https://images.unsplash.com/photo-1682686580391-615b1e32be1f?q=100&w=1920&auto=format&fit=crop', caption: 'Soyut' },
    { id: 11, url: 'https://images.unsplash.com/photo-1682686580186-b55d2a91053c?q=100&w=1920&auto=format&fit=crop', caption: 'Minimalist' },
    { id: 12, url: 'https://images.unsplash.com/photo-1682686580950-960d1d513532?q=100&w=1920&auto=format&fit=crop', caption: 'Sanat' }
  ]);

  const backgrounds = [
    'https://images.unsplash.com/photo-1470219556762-1771e7f9427d?q=100&w=3840&h=2160&fit=crop',
    'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=100&w=3840&h=2160&fit=crop',
    'https://images.unsplash.com/photo-1519659528534-7fd733a832a0?q=100&w=3840&h=2160&fit=crop',
    'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?q=100&w=3840&h=2160&fit=crop'
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBgIndex(prev => (prev + 1) % backgrounds.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const rows = [
    exploreImages.slice(0, 4),
    exploreImages.slice(4, 8),
    exploreImages.slice(8, 12)
  ];

  return (
    <div className="min-h-screen text-white flex flex-col relative">
      {/* Siyah overlay */}
      <div className="fixed inset-0 bg-black opacity-100 z-0" />
      
      {backgrounds.map((bg, index) => (
        <div
          key={index}
          className={`fixed inset-0 transition-opacity duration-1000 bg-cover bg-center bg-no-repeat ${
            index === currentBgIndex ? 'opacity-50' : 'opacity-0'
          }`}
          style={{
            backgroundImage: `url(${bg})`,
            zIndex: -1
          }}
        />
      ))}
      
      <div className="relative z-10 flex flex-col min-h-screen">
        <Navbar />
        
        <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <CitySlideshow />
          
          <div className="mt-16 mb-8">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-purple-500 text-transparent bg-clip-text">
              Keşfet
            </h2>
          </div>

          <div className="space-y-6">
            {rows.map((row, rowIndex) => (
              <div key={rowIndex} className="grid grid-cols-4 gap-6">
                {row.map(image => (
                  <div 
                    key={image.id} 
                    className="group bg-black/100 backdrop-blur-sm rounded-lg overflow-hidden border border-gray-800 hover:border-purple-500/30 transition-all duration-300"
                  >
                    <div className="relative aspect-[4/3] overflow-hidden">
                      <img 
                        src={image.url} 
                        alt={image.caption} 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/100 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    </div>
                    <div className="p-4">
                      <p className="text-lg font-semibold text-white group-hover:text-purple-400 transition-colors">
                        {image.caption}
                      </p>
                      <p className="text-sm text-gray-400 mt-1">
                        Yapay zeka ile oluşturuldu
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </main>
        <Footer />
      </div>
    </div>
  );
}

export default Home;