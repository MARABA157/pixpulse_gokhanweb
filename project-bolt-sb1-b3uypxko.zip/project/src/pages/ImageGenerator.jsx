import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { generateImageWithHF } from '../lib/ai';
import Footer from '../components/Footer';

export default function ImageGenerator() {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [generatedImage, setGeneratedImage] = useState(null);
  const [currentBgIndex, setCurrentBgIndex] = useState(0);

  const backgrounds = [
    'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?q=100&w=3840&h=2160&fit=crop',
    'https://images.unsplash.com/photo-1514565131-fce0801e5785?q=100&w=3840&h=2160&fit=crop',
    'https://images.unsplash.com/photo-1444090542259-0af8fa96557e?q=100&w=3840&h=2160&fit=crop',
    'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?q=100&w=3840&h=2160&fit=crop'
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBgIndex((prevIndex) => (prevIndex + 1) % backgrounds.length);
    }, 2000);

    return () => clearInterval(timer);
  }, []);

  const handleGenerate = async (e) => {
    e.preventDefault();
    if (!prompt.trim()) {
      setError('Lütfen bir açıklama girin');
      return;
    }
    
    try {
      setError(null);
      setLoading(true);
      const imageUrl = await generateImageWithHF(prompt);
      setGeneratedImage(imageUrl);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen text-white flex flex-col relative overflow-hidden">
      {/* Siyah overlay */}
      <div className="fixed inset-0 bg-black opacity-100 z-0" />
      
      {backgrounds.map((bg, index) => (
        <div
          key={index}
          className={`fixed inset-0 transition-opacity duration-1000 bg-cover bg-center bg-no-repeat ${
            index === currentBgIndex ? 'opacity-50' : 'opacity-0'
          }`}
          style={{
            backgroundImage: `url(${bg})`,
            zIndex: -1
          }}
        />
      ))}
      
      <div className="relative z-10 flex flex-col min-h-screen">
        <nav className="bg-black/100 backdrop-blur-sm border-b border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16 items-center">
              <Link to="/" className="text-3xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 text-transparent bg-clip-text hover:from-purple-400 hover:to-pink-400 transition-all">
                PixPulse
              </Link>
            </div>
          </div>
        </nav>
        
        <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text text-center">
              Hayal Et, Gerçeğe Dönüştür
            </h1>
            <p className="text-gray-300 text-center mb-8">
              Yapay zeka ile hayalinizdeki görselleri saniyeler içinde oluşturun
            </p>
            <form onSubmit={handleGenerate} className="space-y-6 bg-black/100 backdrop-blur-md p-8 rounded-xl border border-white/10 shadow-xl">
              <div>
                <label className="block text-lg font-medium mb-3 text-gray-200">Görselinizi Tanımlayın</label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows="4"
                  className="w-full bg-black/100 border border-gray-600 rounded-xl p-4 text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all resize-none"
                  placeholder="Üretmek istediğiniz görseli açıklayın..."
                  required
                />
              </div>
              <button
                type="submit"
                disabled={loading || !prompt.trim()}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-4 rounded-xl font-medium hover:from-purple-500 hover:to-pink-500 transition-all transform hover:scale-[1.02] disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Görsel Üretiliyor...
                  </>
                ) : (
                  'Görsel Üret'
                )}
              </button>
            </form>
            {error && (
              <div className="mt-6 p-4 bg-red-900/100 backdrop-blur border border-red-800 rounded-xl text-red-200 animate-shake">
                {error}
              </div>
            )}
            {generatedImage && (
              <div className="mt-8 bg-black/100 backdrop-blur-md p-6 rounded-xl border border-white/10">
                <h2 className="text-xl font-semibold mb-4 text-gray-200">Üretilen Görsel</h2>
                <img
                  src={generatedImage}
                  alt="Generated"
                  loading="lazy"
                  className="w-full rounded-xl shadow-2xl transform hover:scale-[1.02] transition-all cursor-pointer"
                  onError={(e) => {
                    setError('Görsel yüklenirken bir hata oluştu');
                    e.target.style.display = 'none';
                  }}
                />
              </div>
            )}
          </div>
        </main>
        <Footer />
      </div>
    </div>
  );
}