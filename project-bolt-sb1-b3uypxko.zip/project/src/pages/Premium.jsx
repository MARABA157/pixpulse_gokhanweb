import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const PricingCard = ({ title, price, features, recommended, buttonText, onClick }) => (
  <div className={`relative backdrop-blur-xl bg-white/5 rounded-2xl border ${recommended ? 'border-purple-500' : 'border-white/10'} p-8 flex flex-col`}>
    {recommended && (
      <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-1 rounded-full text-sm font-medium">
        Önerilen
      </div>
    )}
    <h3 className="text-2xl font-bold text-white mb-2">{title}</h3>
    <div className="mb-6">
      <span className="text-4xl font-bold text-white">{price}</span>
      <span className="text-gray-400 ml-2">/ay</span>
    </div>
    <ul className="space-y-4 mb-8 flex-1">
      {features.map((feature, index) => (
        <li key={index} className="flex items-start">
          <svg className="h-6 w-6 text-purple-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
          <span className="text-gray-300">{feature}</span>
        </li>
      ))}
    </ul>
    <button
      onClick={onClick}
      className={`w-full py-4 rounded-xl font-medium transition-all transform hover:scale-[1.02] ${
        recommended
          ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-500 hover:to-pink-500'
          : 'bg-white/10 text-white hover:bg-white/20'
      }`}
    >
      {buttonText}
    </button>
  </div>
);

export default function Premium() {
  const { user } = useAuth();

  const plans = [
    {
      title: 'Başlangıç',
      price: '₺199',
      features: [
        'Aylık 100 görsel oluşturma',
        'Aylık 50 video oluşturma',
        'Temel yapay zeka sohbet',
        'Standart çözünürlük',
        'E-posta desteği'
      ],
      buttonText: 'Başla',
      recommended: false
    },
    {
      title: 'Pro',
      price: '₺399',
      features: [
        'Aylık 500 görsel oluşturma',
        'Aylık 200 video oluşturma',
        'Gelişmiş yapay zeka sohbet',
        'Yüksek çözünürlük',
        'Öncelikli destek',
        'Özel model eğitimi'
      ],
      buttonText: 'Pro\'ya Geç',
      recommended: true
    },
    {
      title: 'Enterprise',
      price: '₺999',
      features: [
        'Sınırsız görsel oluşturma',
        'Sınırsız video oluşturma',
        'Özel yapay zeka modelleri',
        'Ultra yüksek çözünürlük',
        '7/24 özel destek',
        'API erişimi',
        'Özel entegrasyonlar'
      ],
      buttonText: 'İletişime Geç',
      recommended: false
    }
  ];

  const models = [
    {
      name: 'GPT-3.5',
      description: 'Hızlı ve ekonomik yapay zeka sohbet modeli',
      price: '₺0.02 / 1K token',
      context: '4K token context'
    },
    {
      name: 'GPT-4',
      description: 'En gelişmiş yapay zeka dil modeli',
      price: '₺0.20 / 1K token',
      context: '8K token context'
    },
    {
      name: 'DALL-E 3',
      description: 'Yüksek kaliteli görsel üretim modeli',
      price: '₺0.10 / görsel',
      context: '1024x1024 çözünürlük'
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <div className="relative overflow-hidden pt-24 pb-16">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-black" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text animate-text mb-4">
              Premium'a Geçin
            </h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Yapay zeka teknolojilerimizin tüm gücünü keşfedin. Sınırsız üretim, özel modeller ve daha fazlası.
            </p>
          </div>
        </div>
      </div>

      {/* Pricing Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <PricingCard key={index} {...plan} />
          ))}
        </div>
      </div>

      {/* Model Pricing */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Model Fiyatlandırması</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {models.map((model, index) => (
            <div key={index} className="backdrop-blur-xl bg-white/5 rounded-2xl border border-white/10 p-6">
              <h3 className="text-xl font-bold text-white mb-2">{model.name}</h3>
              <p className="text-gray-400 mb-4">{model.description}</p>
              <div className="text-2xl font-bold text-purple-400 mb-2">{model.price}</div>
              <p className="text-gray-400">{model.context}</p>
            </div>
          ))}
        </div>
      </div>

      {/* FAQ Section */}
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Sıkça Sorulan Sorular</h2>
        <div className="space-y-8">
          <div>
            <h3 className="text-xl font-bold mb-2">Premium üyelik nasıl çalışır?</h3>
            <p className="text-gray-400">Premium üyelik, seçtiğiniz plana göre aylık olarak yenilenir. İstediğiniz zaman iptal edebilirsiniz.</p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-2">Ödeme yöntemleri nelerdir?</h3>
            <p className="text-gray-400">Kredi kartı, banka kartı ve havale/EFT ile ödeme yapabilirsiniz.</p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-2">İade politikanız nedir?</h3>
            <p className="text-gray-400">İlk 7 gün içinde iade garantisi sunuyoruz. Memnun kalmazsanız paranızı iade ediyoruz.</p>
          </div>
        </div>
      </div>
    </div>
  );
}