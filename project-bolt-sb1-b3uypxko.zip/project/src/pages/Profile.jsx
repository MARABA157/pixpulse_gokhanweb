import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Link } from 'react-router-dom';
import Footer from '../components/Footer';

export default function Profile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [stats, setStats] = useState({
    images: 0,
    videos: 0,
    favorites: 0
  });
  const [gallery, setGallery] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchProfile();
      fetchStats();
      fetchGallery();
    }
  }, [user]);

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      setProfile(data);
    } catch (error) {
      console.error('Profil yükleme hatası:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const { data: images, error: imagesError } = await supabase
        .from('images')
        .select('count')
        .eq('user_id', user.id);

      if (imagesError) throw imagesError;

      setStats(prev => ({
        ...prev,
        images: images[0]?.count || 0
      }));
    } catch (error) {
      console.error('İstatistik yükleme hatası:', error);
    }
  };

  const fetchGallery = async () => {
    try {
      const { data, error } = await supabase
        .from('images')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(12);

      if (error) throw error;
      setGallery(data || []);
    } catch (error) {
      console.error('Galeri yükleme hatası:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen text-white flex flex-col relative overflow-hidden bg-gradient-to-b from-black to-gray-900">
      <div className="relative z-10 flex flex-col min-h-screen">
        <nav className="border-b border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16 items-center">
              <Link to="/" className="text-4xl font-bold bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 text-transparent bg-clip-text">
                PixPulse
              </Link>
            </div>
          </div>
        </nav>

        <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
            </div>
          ) : (
            <>
              <div className="bg-black/30 rounded-xl p-8 backdrop-blur-sm border border-gray-800">
                <div className="flex items-center space-x-8">
                  <div className="w-32 h-32 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center text-4xl font-bold">
                    {profile?.username?.[0]?.toUpperCase()}
                  </div>
                  <div>
                    <h1 className="text-3xl font-bold mb-2">{profile?.username}</h1>
                    <p className="text-gray-400">{profile?.full_name}</p>
                    <div className="flex space-x-8 mt-4">
                      <div>
                        <p className="text-2xl font-bold">{stats.images}</p>
                        <p className="text-sm text-gray-400">Görsel</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold">{stats.videos}</p>
                        <p className="text-sm text-gray-400">Video</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold">{stats.favorites}</p>
                        <p className="text-sm text-gray-400">Favori</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-12">
                <h2 className="text-2xl font-bold mb-6">Galeri</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {gallery.map((item) => (
                    <div key={item.id} className="group relative aspect-square rounded-xl overflow-hidden bg-black/30 border border-gray-800 hover:border-purple-500/30 transition-all">
                      <img
                        src={item.url}
                        alt={item.caption}
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className="absolute bottom-0 left-0 right-0 p-4">
                          <p className="text-sm text-white">{item.caption}</p>
                          <p className="text-xs text-gray-400 mt-1">
                            {new Date(item.created_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </main>
        <Footer />
      </div>
    </div>
  );
}