import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import FormInput from '../components/FormInput';
import LoadingButton from '../components/LoadingButton';

export default function ResetPassword() {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    // URL'den hash parametrelerini kontrol et
    const hashParams = new URLSearchParams(window.location.hash.substring(1));
    if (!hashParams.get('access_token')) {
      navigate('/signin');
    }
  }, [navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setError(null);
      
      if (password.length < 6) {
        setError('Şifre en az 6 karakter olmalıdır');
        return;
      }

      if (password !== confirmPassword) {
        setError('Şifreler eşleşmiyor');
        return;
      }

      setLoading(true);
      const { error } = await supabase.auth.updateUser({ password });

      if (error) throw error;

      navigate('/signin');
    } catch (error) {
      console.error('Şifre güncelleme hatası:', error);
      setError('Şifre güncellenirken bir hata oluştu. Lütfen tekrar deneyin.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden py-12 px-4 sm:px-6 lg:px-8">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-gray-900 to-black">
        <div className="absolute inset-0 bg-black opacity-50"></div>
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1620121692029-d088224ddc74?w=1920')] bg-cover bg-center opacity-10"></div>
      </div>

      <div className="relative max-w-md w-full">
        <div className="text-center mb-8">
          <Link to="/" className="inline-block">
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text">
              PixPulse
            </h1>
          </Link>
          <h2 className="mt-2 text-2xl font-semibold text-white">Yeni Şifre Belirleyin</h2>
          <p className="mt-2 text-gray-400">Güvenli bir şifre seçin</p>
        </div>

        <div className="backdrop-blur-xl bg-white/10 p-8 rounded-2xl border border-white/20">
          <form onSubmit={handleSubmit} className="space-y-6">
            <FormInput
              label="Yeni Şifre"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              disabled={loading}
              required
            />

            <FormInput
              label="Şifre Tekrar"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="••••••••"
              disabled={loading}
              required
            />

            {error && (
              <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/50 text-red-200 text-sm">
                {error}
              </div>
            )}

            <LoadingButton
              type="submit"
              loading={loading}
              loadingText="Güncelleniyor..."
            >
              Şifreyi Güncelle
            </LoadingButton>
          </form>
        </div>
      </div>
    </div>
  );
}