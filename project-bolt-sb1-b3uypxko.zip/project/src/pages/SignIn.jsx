import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import FormInput from '../components/FormInput'
import LoadingButton from '../components/LoadingButton'

const SignIn = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(false)
  const { signIn } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    try {
      setError(null)
      
      if (!email || !password) {
        setError('Lütfen tüm alanları doldurun')
        return
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!emailRegex.test(email)) {
        setError('Geçerli bir e-posta adresi giriniz')
        return
      }

      setLoading(true)
      await signIn(email, password)
      navigate('/')
    } catch (error) {
      console.error('Giriş hatası:', error)
      setError('E-posta veya şifre hatalı')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden py-12 px-4 sm:px-6 lg:px-8">
      {/* Animasyonlu arka plan */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-gray-900 to-black animate-gradient-x">
        <div className="absolute inset-0 bg-black opacity-50"></div>
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1620121692029-d088224ddc74?w=1920')] bg-cover bg-center opacity-10"></div>
      </div>

      <div className="relative max-w-md w-full space-y-8">
        <div className="text-center">
          <Link to="/" className="inline-block">
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text animate-text">
              PixPulse
            </h1>
          </Link>
          <h2 className="mt-6 text-3xl font-extrabold text-white">
            Tekrar Hoşgeldiniz
          </h2>
          <p className="mt-2 text-sm text-gray-400">
            Yapay zeka ile harika içerikler oluşturmaya devam edin
          </p>
        </div>

        <div className="backdrop-blur-xl bg-white/10 p-8 rounded-2xl border border-white/20 shadow-xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            <FormInput
              label="E-posta"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="ornek@email.com"
              disabled={loading}
              required
            />

            <FormInput
              label="Şifre"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              disabled={loading}
              required
            />

            {error && (
              <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/50 text-red-200 text-sm animate-shake">
                {error}
              </div>
            )}

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <input
                  id="remember-me"
                  name="remember-me"
                  type="checkbox"
                  className="h-4 w-4 rounded border-gray-600 bg-gray-800 text-purple-500 focus:ring-purple-500"
                />
                <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-400">
                  Beni hatırla
                </label>
              </div>

              <Link
                to="/forgot-password"
                className="text-sm font-medium text-purple-400 hover:text-purple-300 transition-colors"
              >
                Şifremi unuttum
              </Link>
            </div>

            <LoadingButton
              type="submit"
              loading={loading}
              loadingText="Giriş yapılıyor..."
              className="w-full"
            >
              Giriş Yap
            </LoadingButton>
          </form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-700"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-black text-gray-400">veya</span>
              </div>
            </div>

            <div className="mt-6 text-center">
              <p className="text-gray-400">
                Hesabınız yok mu?{' '}
                <Link
                  to="/signup"
                  className="font-medium text-purple-400 hover:text-purple-300 transition-colors"
                >
                  Hemen Kayıt Olun
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SignIn