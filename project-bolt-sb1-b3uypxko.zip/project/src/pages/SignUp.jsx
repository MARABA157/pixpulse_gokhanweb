import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import FormInput from '../components/FormInput'
import LoadingButton from '../components/LoadingButton'

export default function SignUp() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(false)
  const { signUp } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    try {
      setError(null)
      
      if (!email || !password || !confirmPassword) {
        setError('Lütfen tüm alanları doldurun')
        return
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!emailRegex.test(email)) {
        setError('Geçerli bir e-posta adresi giriniz')
        return
      }

      if (password.length < 6) {
        setError('Şifre en az 6 karakter olmalıdır')
        return
      }

      if (password !== confirmPassword) {
        setError('Şifreler eşleşmiyor')
        return
      }

      setLoading(true)
      await signUp(email, password)
      navigate('/signin')
    } catch (error) {
      console.error('Kayıt hatası:', error)
      setError('Bu e-posta adresi zaten kullanımda')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden py-12 px-4 sm:px-6 lg:px-8">
      {/* Animasyonlu arka plan */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-gray-900 to-black animate-gradient-x">
        <div className="absolute inset-0 bg-black opacity-50"></div>
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1620121692029-d088224ddc74?w=1920')] bg-cover bg-center opacity-10"></div>
      </div>

      <div className="relative max-w-md w-full space-y-8">
        <div className="text-center">
          <Link to="/" className="inline-block">
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text animate-text">
              PixPulse
            </h1>
          </Link>
          <h2 className="mt-6 text-3xl font-extrabold text-white">
            Hesap Oluşturun
          </h2>
          <p className="mt-2 text-sm text-gray-400">
            Yapay zeka ile içerik üretmeye hemen başlayın
          </p>
        </div>

        <div className="backdrop-blur-xl bg-white/10 p-8 rounded-2xl border border-white/20 shadow-xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            <FormInput
              label="E-posta"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="ornek@email.com"
              disabled={loading}
              required
            />

            <FormInput
              label="Şifre"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              disabled={loading}
              required
            />

            <FormInput
              label="Şifre Tekrar"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="••••••••"
              disabled={loading}
              required
            />

            {error && (
              <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/50 text-red-200 text-sm animate-shake">
                {error}
              </div>
            )}

            <div className="text-sm text-gray-400">
              <p>Şifreniz:</p>
              <ul className="list-disc list-inside mt-1 space-y-1">
                <li className={password.length >= 6 ? 'text-green-400' : ''}>
                  En az 6 karakter uzunluğunda olmalı
                </li>
                <li className={/[A-Z]/.test(password) ? 'text-green-400' : ''}>
                  En az bir büyük harf içermeli
                </li>
                <li className={/[0-9]/.test(password) ? 'text-green-400' : ''}>
                  En az bir rakam içermeli
                </li>
              </ul>
            </div>

            <LoadingButton
              type="submit"
              loading={loading}
              loadingText="Kayıt yapılıyor..."
              className="w-full"
            >
              Kayıt Ol
            </LoadingButton>
          </form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-700"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-black text-gray-400">veya</span>
              </div>
            </div>

            <div className="mt-6 text-center">
              <p className="text-gray-400">
                Zaten hesabınız var mı?{' '}
                <Link
                  to="/signin"
                  className="font-medium text-purple-400 hover:text-purple-300 transition-colors"
                >
                  Giriş Yapın
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}