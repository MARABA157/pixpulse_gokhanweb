import { useState } from 'react'
import { Link } from 'react-router-dom'

export default function Upload() {
  const [uploading, setUploading] = useState(false)
  const [caption, setCaption] = useState('')
  const [error, setError] = useState(null)

  const handleUpload = async (e) => {
    try {
      setError(null)
      
      if (!e.target.files || e.target.files.length === 0) {
        throw new Error('Lütfen bir görsel seçin.');
      }

      setUploading(true)
      // Upload işlemleri buraya gelecek
      
    } catch (error) {
      setError(error.message)
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="min-h-screen bg-black text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-2xl font-bold">Görsel Yükle</h1>
            <Link to="/" className="text-gray-400 hover:text-white transition-colors">
              Ana Sayfaya Dön
            </Link>
          </div>
          <div className="space-y-6 bg-gray-900 p-8 rounded-lg border border-gray-800">
            <div>
              <label className="block text-sm font-medium mb-2">Görsel</label>
              <input
                type="file"
                accept="image/*"
                onChange={handleUpload}
                disabled={uploading}
                className="block w-full text-sm text-gray-400
                  file:mr-4 file:py-2 file:px-4
                  file:rounded-md file:border-0
                  file:text-sm file:font-medium
                  file:bg-gray-800 file:text-white
                  hover:file:bg-gray-700
                  file:cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Açıklama</label>
              <input
                type="text"
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                disabled={uploading}
                className="block w-full rounded-md border-gray-700 bg-gray-800 text-white px-4 py-2 focus:border-gray-500 focus:ring-gray-500 sm:text-sm"
                placeholder="Bir açıklama ekleyin..."
              />
            </div>
            {error && (
              <div className="text-red-500 text-sm">{error}</div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}