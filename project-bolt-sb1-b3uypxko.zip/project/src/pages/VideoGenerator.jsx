import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { generateVideo } from '../lib/video';
import Footer from '../components/Footer';

export default function VideoGenerator() {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [generatedVideo, setGeneratedVideo] = useState(null);
  const [currentBgIndex, setCurrentBgIndex] = useState(0);

  const backgrounds = [
    'https://images.unsplash.com/photo-1485846234645-a62644f84728?q=100&w=3840&h=2160&fit=crop',
    'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=100&w=3840&h=2160&fit=crop',
    'https://images.unsplash.com/photo-1478720568477-152d9b164e26?q=100&w=3840&h=2160&fit=crop',
    'https://images.unsplash.com/photo-1595859703065-2c794f06b4d3?q=100&w=3840&h=2160&fit=crop'
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBgIndex((prevIndex) => (prevIndex + 1) % backgrounds.length);
    }, 2000);

    return () => clearInterval(timer);
  }, []);

  const handleGenerate = async (e) => {
    e.preventDefault();
    if (!prompt.trim()) {
      setError('Lütfen bir açıklama girin');
      return;
    }
    
    try {
      setError(null);
      setLoading(true);
      const videoUrl = await generateVideo(prompt);
      setGeneratedVideo(videoUrl);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen text-white flex flex-col relative overflow-hidden">
      {/* Siyah overlay */}
      <div className="fixed inset-0 bg-black opacity-100 z-0" />
      
      {backgrounds.map((bg, index) => (
        <div
          key={index}
          className={`fixed inset-0 transition-opacity duration-1000 bg-cover bg-center bg-no-repeat ${
            index === currentBgIndex ? 'opacity-50' : 'opacity-0'
          }`}
          style={{
            backgroundImage: `url(${bg})`,
            zIndex: -1
          }}
        />
      ))}
      
      <div className="relative z-10 flex flex-col min-h-screen">
        <nav className="bg-black/100 backdrop-blur-sm border-b border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16 items-center">
              <Link to="/" className="text-3xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 text-transparent bg-clip-text hover:from-purple-400 hover:to-pink-400 transition-all">
                PixPulse
              </Link>
            </div>
          </div>
        </nav>
        
        <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text text-center">
              Video Hayallerinizi Gerçeğe Dönüştürün
            </h1>
            <p className="text-gray-300 text-center mb-8">
              Yapay zeka ile etkileyici videolar oluşturun
            </p>
            <form onSubmit={handleGenerate} className="space-y-6 bg-black/100 backdrop-blur-md p-8 rounded-xl border border-white/10 shadow-xl">
              <div>
                <label className="block text-lg font-medium mb-3 text-gray-200">Videonuzu Tanımlayın</label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows="4"
                  className="w-full bg-black/100 border border-gray-600 rounded-xl p-4 text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all resize-none"
                  placeholder="Üretmek istediğiniz videoyu açıklayın..."
                  required
                />
              </div>
              <button
                type="submit"
                disabled={loading || !prompt.trim()}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-4 rounded-xl font-medium hover:from-purple-500 hover:to-pink-500 transition-all transform hover:scale-[1.02] disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Video Üretiliyor...
                  </>
                ) : (
                  'Video Üret'
                )}
              </button>
            </form>
            {error && (
              <div className="mt-6 p-4 bg-red-900/100 backdrop-blur border border-red-800 rounded-xl text-red-200 animate-shake">
                {error}
              </div>
            )}
            {generatedVideo && (
              <div className="mt-8 bg-black/100 backdrop-blur-md p-6 rounded-xl border border-white/10">
                <h2 className="text-xl font-semibold mb-4 text-gray-200">Üretilen Video</h2>
                <video
                  src={generatedVideo}
                  controls
                  className="w-full rounded-xl shadow-2xl"
                  autoPlay
                  loop
                >
                  Tarayıcınız video oynatmayı desteklemiyor.
                </video>
              </div>
            )}
          </div>
        </main>
        <Footer />
      </div>
    </div>
  );
}