import { precacheAndRoute } from 'workbox-precaching';
import { registerRoute } from 'workbox-routing';
import { CacheFirst, NetworkFirst } from 'workbox-strategies';
import { ExpirationPlugin } from 'workbox-expiration';

// Precache tüm statik varlıklar
precacheAndRoute(self.__WB_MANIFEST);

// API istekleri için Network First stratejisi
registerRoute(
  ({ url }) => url.pathname.startsWith('/api/'),
  new NetworkFirst({
    cacheName: 'api-cache',
    plugins: [
      new ExpirationPlugin({
        maxEntries: 50,
        maxAgeSeconds: 60 * 60 // 1 saat
      })
    ]
  })
);

// Görseller için Cache First stratejisi
registerRoute(
  ({ request }) => request.destination === 'image',
  new CacheFirst({
    cacheName: 'image-cache',
    plugins: [
      new ExpirationPlugin({
        maxEntries: 60,
        maxAgeSeconds: 30 * 24 * 60 * 60 // 30 gün
      })
    ]
  })
);

// Offline sayfası
const offlinePage = new Response(
  '<html><body><h1>Çevrimdışısınız</h1><p>İnternet bağlantınızı kontrol edin.</p></body></html>',
  {
    headers: { 'Content-Type': 'text/html' }
  }
);

// Offline durumunda özel sayfa göster
self.addEventListener('fetch', (event) => {
  if (!navigator.onLine) {
    event.respondWith(offlinePage);
  }
});