/*
  # Add profile trigger

  1. Changes
    - Add function to handle new user registration
    - Create trigger to automatically create profile for new users
    
  2. Security
    - Function runs with security definer to ensure it can create profiles
*/

-- Create function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, username, full_name)
  VALUES (
    new.id,
    SPLIT_PART(new.email, '@', 1), -- Use part before @ as username
    SPLIT_PART(new.email, '@', 1)  -- Initially set full name same as username
  );
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user signup
CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();