/*
  # Auto confirm user emails

  1. Changes
    - Create a trigger to automatically confirm user emails upon signup
    - This removes the need for email verification

  2. Security Note
    - This is a development/testing configuration
    - For production, email confirmation should be properly implemented
*/

-- Function to auto-confirm user emails
CREATE OR REPLACE FUNCTION public.auto_confirm_email()
RETURNS trigger AS $$
BEGIN
  -- Set email_confirmed_at to current timestamp
  NEW.email_confirmed_at = NOW();
  -- Set confirmed_at to current timestamp
  NEW.confirmed_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to auto-confirm emails for new users
DROP TRIGGER IF EXISTS confirm_user_email ON auth.users;
CREATE TRIGGER confirm_user_email
  BEFORE INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_confirm_email();