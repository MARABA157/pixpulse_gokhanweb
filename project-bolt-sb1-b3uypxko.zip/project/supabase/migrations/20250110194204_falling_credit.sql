/*
  # Fix email confirmation

  1. Changes
    - Update existing users to confirm their emails
    - Add trigger for auto-confirming new user emails
*/

-- Update existing users to confirm their emails
UPDATE auth.users
SET email_confirmed_at = NOW()
WHERE email_confirmed_at IS NULL;

-- Function to auto-confirm user emails
CREATE OR REPLACE FUNCTION public.auto_confirm_email()
RETURNS trigger AS $$
BEGIN
  -- Set email_confirmed_at to current timestamp
  NEW.email_confirmed_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to auto-confirm emails for new users
DROP TRIGGER IF EXISTS confirm_user_email ON auth.users;
CREATE TRIGGER confirm_user_email
  BEFORE INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_confirm_email();